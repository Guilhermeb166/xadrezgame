import GameManager from './components/GameManager';

import './App.css'

function App() {
    return (
    <div>
      <GameManager />
    </div>
  );
}

export default App
